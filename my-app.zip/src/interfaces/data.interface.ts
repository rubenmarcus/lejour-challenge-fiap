export interface QueryParams  {
    limit: number,
    query_type: 'and',
    Name: string,
} 